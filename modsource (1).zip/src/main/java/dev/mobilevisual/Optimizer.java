package dev.mobilevisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;

/** Пресет настроек графики для слабых устройств / телефонов. */
public final class Optimizer {
    private Optimizer() {}

    public static void applyMobilePreset(MinecraftClient client) {
        GameOptions o = client.options;
        o.getViewDistance().setValue(6);
        o.getSimulationDistance().setValue(5);
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getEntityShadows().setValue(false);
        o.getBiomeBlendRadius().setValue(0);
        o.getEntityDistanceScaling().setValue(0.75);
        o.getMaxFps().setValue(60);
        o.write();
    }
}
