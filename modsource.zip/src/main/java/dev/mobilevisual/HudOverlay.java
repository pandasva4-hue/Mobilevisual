package dev.mobilevisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import java.util.Locale;

/** Лёгкий HUD: только текст и иконки предметов через стандартный DrawContext (без своих шейдеров/GL). */
public final class HudOverlay {
    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };
    private static final int WHITE = 0xFFFFFFFF;

    private HudOverlay() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        if (!Config.hud && !Config.armor) return;

        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || client.options.hudHidden) return;

        TextRenderer font = client.textRenderer;

        if (Config.hud) {
            int y = 4;
            ctx.drawTextWithShadow(font, "FPS: " + client.getCurrentFps(), 4, y, WHITE);
            y += 10;
            ctx.drawTextWithShadow(font, String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f",
                    player.getX(), player.getY(), player.getZ()), 4, y, WHITE);
            y += 10;

            if (Config.ping && client.getNetworkHandler() != null) {
                PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(player.getUuid());
                if (entry != null) {
                    ctx.drawTextWithShadow(font, "Ping: " + entry.getLatency() + " ms", 4, y, WHITE);
                }
            }
        }

        if (Config.armor) {
            int x = ctx.getScaledWindowWidth() - 22;
            int y = 4;
            for (EquipmentSlot slot : ARMOR) {
                ItemStack stack = player.getEquippedStack(slot);
                if (stack.isEmpty()) continue;
                ctx.drawItem(stack, x, y);
                ctx.drawStackOverlay(font, stack, x, y);
                y += 18;
            }
        }
    }
}
