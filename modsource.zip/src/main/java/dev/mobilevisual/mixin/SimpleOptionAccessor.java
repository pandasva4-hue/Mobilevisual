package dev.mobilevisual.mixin;

import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Позволяет записать значение опции в обход проверки диапазона
 * (нужно для гаммы > 1.0, т.е. фулбрайта).
 */
@Mixin(SimpleOption.class)
public interface SimpleOptionAccessor {
    @Accessor("value")
    void mobilevisual$setValue(Object value);
}
