package dev.mobilevisual;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Простые настройки, сохраняются в config/mobilevisual.properties. */
public final class Config {
    public static boolean hud = true;
    public static boolean armor = true;
    public static boolean ping = false;
    public static boolean fullbright = false;
    public static boolean clearWeather = false;

    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("mobilevisual.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            Properties p = new Properties();
            p.load(r);
            hud = Boolean.parseBoolean(p.getProperty("hud", "true"));
            armor = Boolean.parseBoolean(p.getProperty("armor", "true"));
            ping = Boolean.parseBoolean(p.getProperty("ping", "false"));
            fullbright = Boolean.parseBoolean(p.getProperty("fullbright", "false"));
            clearWeather = Boolean.parseBoolean(p.getProperty("clearWeather", "false"));
        } catch (IOException ignored) {
        }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("hud", Boolean.toString(hud));
        p.setProperty("armor", Boolean.toString(armor));
        p.setProperty("ping", Boolean.toString(ping));
        p.setProperty("fullbright", Boolean.toString(fullbright));
        p.setProperty("clearWeather", Boolean.toString(clearWeather));
        try (Writer w = Files.newBufferedWriter(file())) {
            p.store(w, "Mobile Visual");
        } catch (IOException ignored) {
        }
    }
}
