package dev.mobilevisual;

import dev.mobilevisual.mixin.SimpleOptionAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;

/** Логика, которая выполняется каждый тик: фулбрайт, зум, чистая погода. */
public final class Effects {
    private static final double FULL_GAMMA = 15.0;
    private static final int ZOOM_FOV = 30;

    private static boolean fullbrightApplied = false;
    private static double savedGamma = 1.0;

    private static boolean zooming = false;
    private static int savedFov = 70;

    private Effects() {}

    public static void tick(MinecraftClient client, boolean zoomPressed) {
        if (client.options == null) return;
        tickFullbright(client);
        tickZoom(client, zoomPressed);

        if (Config.clearWeather && client.world != null) {
            client.world.setRainGradient(0.0f);
            client.world.setThunderGradient(0.0f);
        }
    }

    private static void tickFullbright(MinecraftClient client) {
        SimpleOption<Double> gamma = client.options.getGamma();
        if (Config.fullbright) {
            if (!fullbrightApplied) {
                savedGamma = gamma.getValue();
                fullbrightApplied = true;
            }
            if (gamma.getValue() != FULL_GAMMA) {
                setUnchecked(gamma, FULL_GAMMA);
            }
        } else if (fullbrightApplied) {
            setUnchecked(gamma, savedGamma);
            fullbrightApplied = false;
        }
    }

    private static void tickZoom(MinecraftClient client, boolean zoomPressed) {
        SimpleOption<Integer> fov = client.options.getFov();
        if (zoomPressed && client.currentScreen == null) {
            if (!zooming) {
                savedFov = fov.getValue();
                zooming = true;
            }
            if (fov.getValue() != ZOOM_FOV) {
                fov.setValue(ZOOM_FOV);
            }
        } else if (zooming) {
            fov.setValue(savedFov);
            zooming = false;
        }
    }

    /** Вернуть гамму и FOV, чтобы в options.txt не осталось значений от мода. */
    public static void restore(MinecraftClient client) {
        if (client.options == null) return;
        if (fullbrightApplied) {
            setUnchecked(client.options.getGamma(), savedGamma);
            fullbrightApplied = false;
        }
        if (zooming) {
            client.options.getFov().setValue(savedFov);
            zooming = false;
        }
    }

    private static void setUnchecked(SimpleOption<Double> option, double value) {
        ((SimpleOptionAccessor) (Object) option).mobilevisual$setValue(value);
    }
}
