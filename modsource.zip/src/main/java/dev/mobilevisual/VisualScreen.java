package dev.mobilevisual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Меню с большими кнопками — удобно нажимать пальцем. */
public class VisualScreen extends Screen {
    private static final int W = 150;
    private static final int H = 20;
    private static final int GAP = 4;

    private final Screen parent;

    public VisualScreen(Screen parent) {
        super(Text.literal("Mobile Visual"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int left = this.width / 2 - W - GAP / 2;
        int right = this.width / 2 + GAP / 2;
        int y = Math.max(28, this.height / 2 - 50);
        int step = H + GAP;

        toggle(left, y, "HUD", () -> Config.hud, v -> Config.hud = v);
        toggle(right, y, "Fullbright", () -> Config.fullbright, v -> Config.fullbright = v);
        y += step;

        toggle(left, y, "Armor", () -> Config.armor, v -> Config.armor = v);
        toggle(right, y, "Clear weather", () -> Config.clearWeather, v -> Config.clearWeather = v);
        y += step;

        toggle(left, y, "Ping", () -> Config.ping, v -> Config.ping = v);
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Mobile preset"),
                        b -> Optimizer.applyMobilePreset(MinecraftClient.getInstance()))
                .dimensions(right, y, W, H).build());
        y += step + 8;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> this.close())
                .dimensions(this.width / 2 - W / 2, y, W, H).build());
    }

    private void toggle(int x, int y, String name, BooleanSupplier get, Consumer<Boolean> set) {
        this.addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            Config.save();
            b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(x, y, W, H).build());
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 10, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}
