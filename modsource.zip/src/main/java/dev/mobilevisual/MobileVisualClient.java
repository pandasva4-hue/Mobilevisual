package dev.mobilevisual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class MobileVisualClient implements ClientModInitializer {
    private static KeyBinding menuKey;
    private static KeyBinding zoomKey;

    @Override
    public void onInitializeClient() {
        Config.load();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mobilevisual.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.mobilevisual"));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mobilevisual.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.mobilevisual"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                client.setScreen(new VisualScreen(null));
            }
            Effects.tick(client, zoomKey.isPressed());
        });

        HudRenderCallback.EVENT.register(HudOverlay::render);

        ClientLifecycleEvents.CLIENT_STOPPING.register(Effects::restore);

        // /visual — открыть меню, /visual mobile — применить пресет оптимизации.
        // Команды удобны на телефоне: чат открывается экранной кнопкой.
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("visual")
                        .executes(ctx -> {
                            MinecraftClient mc = ctx.getSource().getClient();
                            mc.send(() -> mc.setScreen(new VisualScreen(null)));
                            return 1;
                        })
                        .then(ClientCommandManager.literal("mobile").executes(ctx -> {
                            Optimizer.applyMobilePreset(ctx.getSource().getClient());
                            ctx.getSource().sendFeedback(Text.literal("Mobile preset applied"));
                            return 1;
                        }))));
    }
}
